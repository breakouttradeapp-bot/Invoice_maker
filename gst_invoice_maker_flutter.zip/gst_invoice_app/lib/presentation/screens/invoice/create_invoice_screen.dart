import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../../data/models/hive/invoice_model.dart';
import '../../../data/models/hive/invoice_item_model.dart';
import '../../../data/models/hive/customer_model.dart';
import '../../../data/repositories/invoice_repository.dart';
import '../../../data/repositories/company_repository.dart';
import '../../../services/gst_calculator_service.dart';
import '../../../services/admob_service.dart';
import '../../widgets/invoice_item_row_widget.dart';
import '../customer/customer_list_screen.dart';
import 'invoice_preview_screen.dart';

class CreateInvoiceScreen extends StatefulWidget {
  final InvoiceModel? existingInvoice;
  const CreateInvoiceScreen({super.key, this.existingInvoice});

  @override
  State<CreateInvoiceScreen> createState() => _CreateInvoiceScreenState();
}

class _CreateInvoiceScreenState extends State<CreateInvoiceScreen> {
  final _formKey = GlobalKey<FormState>();
  final _companyRepo = CompanyRepository();
  final _invoiceRepo = InvoiceRepository();

  // Customer
  CustomerModel? _selectedCustomer;

  // Invoice Details
  late TextEditingController _invoiceNumberCtrl;
  late DateTime _invoiceDate;
  DateTime? _dueDate;
  bool _isReverseCharge = false;
  String _paymentStatus = 'unpaid';
  final _notesCtrl = TextEditingController();
  late TextEditingController _termsCtrl;

  // Items
  final List<_InvoiceItemEntry> _items = [];

  // Additional
  double _shippingCharges = 0;
  int _selectedTemplate = 1;

  InvoiceTaxSummary? _taxSummary;

  @override
  void initState() {
    super.initState();
    final company = _companyRepo.getCompany();
    _invoiceNumberCtrl = TextEditingController(
        text: _companyRepo.generateInvoiceNumber());
    _invoiceDate = DateTime.now();
    _termsCtrl = TextEditingController(
        text: company?.termsAndConditions ?? '');
    _items.add(_InvoiceItemEntry());
    _selectedTemplate = AppConstants.templateBlueCorporate;
  }

  @override
  void dispose() {
    _invoiceNumberCtrl.dispose();
    _notesCtrl.dispose();
    _termsCtrl.dispose();
    super.dispose();
  }

  void _recalculate() {
    final company = _companyRepo.getCompany();
    if (company == null || _selectedCustomer == null) {
      setState(() => _taxSummary = null);
      return;
    }

    final items = _items
        .where((item) => item.productName.isNotEmpty && item.price > 0)
        .map((item) => {
              'quantity': item.quantity,
              'price': item.price,
              'discountPercent': item.discountPercent,
              'gstRate': item.gstRate,
              'isInclusive': item.isInclusive,
            })
        .toList();

    if (items.isEmpty) {
      setState(() => _taxSummary = null);
      return;
    }

    final summary = GSTCalculatorService.calculateInvoice(
      items: items,
      sellerState: company.state,
      buyerState: _selectedCustomer!.state,
      shippingCharges: _shippingCharges,
      isReverseCharge: _isReverseCharge,
    );

    setState(() => _taxSummary = summary);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundGrey,
      appBar: AppBar(
        title: Text(widget.existingInvoice == null
            ? 'Create Invoice'
            : 'Edit Invoice'),
        actions: [
          TextButton.icon(
            onPressed: _previewInvoice,
            icon: const Icon(Icons.preview, color: Colors.white),
            label:
                const Text('Preview', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ── Section: Invoice Details ──
            _sectionCard(
              title: 'Invoice Details',
              icon: Icons.receipt,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _invoiceNumberCtrl,
                        decoration:
                            const InputDecoration(labelText: 'Invoice Number *'),
                        validator: (v) =>
                            v!.isEmpty ? 'Required' : null,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _DatePickerField(
                        label: 'Invoice Date *',
                        selectedDate: _invoiceDate,
                        onDateSelected: (d) =>
                            setState(() => _invoiceDate = d),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _DatePickerField(
                        label: 'Due Date',
                        selectedDate: _dueDate,
                        onDateSelected: (d) => setState(() => _dueDate = d),
                        isOptional: true,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _paymentStatus,
                        decoration:
                            const InputDecoration(labelText: 'Payment Status'),
                        items: const [
                          DropdownMenuItem(
                              value: 'unpaid', child: Text('Unpaid')),
                          DropdownMenuItem(value: 'paid', child: Text('Paid')),
                          DropdownMenuItem(
                              value: 'partial', child: Text('Partial')),
                        ],
                        onChanged: (v) =>
                            setState(() => _paymentStatus = v!),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  value: _isReverseCharge,
                  onChanged: (v) {
                    setState(() => _isReverseCharge = v);
                    _recalculate();
                  },
                  title: const Text('Reverse Charge',
                      style: TextStyle(fontSize: 14)),
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                ),
              ],
            ),

            const SizedBox(height: 12),

            // ── Section: Customer ──
            _sectionCard(
              title: 'Customer',
              icon: Icons.person,
              children: [
                if (_selectedCustomer == null)
                  OutlinedButton.icon(
                    onPressed: _selectCustomer,
                    icon: const Icon(Icons.person_add),
                    label: const Text('Select Customer'),
                  )
                else
                  _CustomerTile(
                    customer: _selectedCustomer!,
                    onClear: () => setState(() {
                      _selectedCustomer = null;
                      _taxSummary = null;
                    }),
                    onTap: _selectCustomer,
                  ),
              ],
            ),

            const SizedBox(height: 12),

            // ── Section: Items ──
            _sectionCard(
              title: 'Items',
              icon: Icons.inventory,
              trailing: TextButton.icon(
                onPressed: () => setState(() => _items.add(_InvoiceItemEntry())),
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Add Item'),
              ),
              children: [
                ..._items.asMap().entries.map((entry) {
                  final i = entry.key;
                  final item = entry.value;
                  return InvoiceItemRowWidget(
                    item: item,
                    index: i,
                    onChanged: (_) => _recalculate(),
                    onDelete: _items.length > 1
                        ? () => setState(() {
                              _items.removeAt(i);
                              _recalculate();
                            })
                        : null,
                  );
                }),
              ],
            ),

            const SizedBox(height: 12),

            // ── Section: Charges & Notes ──
            _sectionCard(
              title: 'Additional Charges',
              icon: Icons.local_shipping,
              children: [
                TextFormField(
                  initialValue: _shippingCharges > 0
                      ? _shippingCharges.toStringAsFixed(2)
                      : '',
                  decoration:
                      const InputDecoration(labelText: 'Shipping Charges (₹)'),
                  keyboardType: TextInputType.number,
                  onChanged: (v) {
                    _shippingCharges = double.tryParse(v) ?? 0;
                    _recalculate();
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _notesCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Notes', hintText: 'Optional notes for customer'),
                  maxLines: 2,
                ),
              ],
            ),

            const SizedBox(height: 12),

            // ── Tax Summary ──
            if (_taxSummary != null) _buildTaxSummary(),

            const SizedBox(height: 12),

            // ── Template Selector ──
            _sectionCard(
              title: 'Invoice Template',
              icon: Icons.design_services,
              children: [
                DropdownButtonFormField<int>(
                  value: _selectedTemplate,
                  decoration:
                      const InputDecoration(labelText: 'Select Template'),
                  items: AppConstants.templates.map((t) {
                    return DropdownMenuItem<int>(
                      value: t['id'] as int,
                      child: Text(t['name'] as String),
                    );
                  }).toList(),
                  onChanged: (v) => setState(() => _selectedTemplate = v!),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // ── Terms ──
            _sectionCard(
              title: 'Terms & Conditions',
              icon: Icons.gavel,
              children: [
                TextFormField(
                  controller: _termsCtrl,
                  maxLines: 4,
                  decoration: const InputDecoration(
                      border: OutlineInputBorder()),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // ── Save Button ──
            ElevatedButton.icon(
              onPressed: _saveInvoice,
              icon: const Icon(Icons.save),
              label: const Text('Save Invoice'),
              style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50)),
            ),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildTaxSummary() {
    final t = _taxSummary!;
    return Card(
      color: const Color(0xFFE8EAF6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tax Summary',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryBlue)),
            const Divider(),
            _summaryRow('Sub Total', t.subTotal),
            if (t.totalDiscount > 0)
              _summaryRow('Total Discount', t.totalDiscount, isNegative: true),
            _summaryRow('Taxable Amount', t.taxableAmount),
            if (!t.isInterState) ...[
              _summaryRow('CGST', t.cgst),
              _summaryRow('SGST', t.sgst),
            ] else
              _summaryRow('IGST', t.igst),
            if (t.shippingCharges > 0)
              _summaryRow('Shipping', t.shippingCharges),
            if (t.roundOff != 0) _summaryRow('Round Off', t.roundOff),
            const Divider(thickness: 1.5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('TOTAL',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.primaryBlue)),
                Text(
                  '₹${t.finalTotal.toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryBlue),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
                t.isInterState
                    ? '(Interstate - IGST applies)'
                    : '(Intrastate - CGST + SGST applies)',
                style: const TextStyle(
                    fontSize: 11, color: AppTheme.textMedium,
                    fontStyle: FontStyle.italic)),
          ],
        ),
      ),
    );
  }

  Widget _summaryRow(String label, double amount,
      {bool isNegative = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 13)),
          Text(
            '${isNegative ? '-' : ''}₹${amount.abs().toStringAsFixed(2)}',
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _sectionCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
    Widget? trailing,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(icon, color: AppTheme.primaryBlue, size: 18),
                    const SizedBox(width: 8),
                    Text(title,
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textDark)),
                  ],
                ),
                if (trailing != null) trailing,
              ],
            ),
            const Divider(),
            ...children,
          ],
        ),
      ),
    );
  }

  Future<void> _selectCustomer() async {
    final customer = await Navigator.push<CustomerModel>(
      context,
      MaterialPageRoute(
          builder: (_) => const CustomerListScreen(selectMode: true)),
    );
    if (customer != null) {
      setState(() => _selectedCustomer = customer);
      _recalculate();
    }
  }

  Future<void> _saveInvoice() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please select a customer')));
      return;
    }
    if (_items.every((i) => i.productName.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please add at least one item')));
      return;
    }

    _recalculate();
    if (_taxSummary == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Unable to calculate taxes')));
      return;
    }

    final company = _companyRepo.getCompany()!;
    final t = _taxSummary!;
    final uuid = const Uuid();

    // Build invoice items
    final invoiceItems = _items
        .where((item) => item.productName.isNotEmpty && item.price > 0)
        .map((item) {
      final calc = GSTCalculatorService.calculateLineItem(LineItemCalculation(
        quantity: item.quantity,
        price: item.price,
        discountPercent: item.discountPercent,
        gstRate: item.gstRate,
        isInclusive: item.isInclusive,
        isInterState: t.isInterState,
      ));
      return InvoiceItemModel(
        productName: item.productName,
        hsnSac: item.hsnSac,
        quantity: item.quantity,
        unit: item.unit,
        price: item.price,
        discountPercent: item.discountPercent,
        gstRate: item.gstRate,
        isInclusive: item.isInclusive,
        taxableAmount: calc.taxableAmount,
        cgst: calc.cgst,
        sgst: calc.sgst,
        igst: calc.igst,
        totalAmount: calc.totalAmount,
      );
    }).toList();

    final invoice = InvoiceModel(
      id: uuid.v4(),
      invoiceNumber: _invoiceNumberCtrl.text.trim(),
      invoiceDate: _invoiceDate,
      dueDate: _dueDate,
      customerId: _selectedCustomer!.id,
      customerName: _selectedCustomer!.name,
      customerGstin: _selectedCustomer!.gstin,
      customerAddress: _selectedCustomer!.address,
      customerState: _selectedCustomer!.state,
      customerPhone: _selectedCustomer!.phone,
      customerEmail: _selectedCustomer!.email,
      sellerState: company.state,
      isInterState: t.isInterState,
      isReverseCharge: _isReverseCharge,
      placeOfSupply: _selectedCustomer!.state,
      items: invoiceItems,
      subTotal: t.subTotal,
      totalDiscount: t.totalDiscount,
      taxableAmount: t.taxableAmount,
      cgst: t.cgst,
      sgst: t.sgst,
      igst: t.igst,
      totalTax: t.totalTax,
      shippingCharges: t.shippingCharges,
      grandTotal: t.grandTotal,
      roundOff: t.roundOff,
      finalTotal: t.finalTotal,
      paymentStatus: _paymentStatus,
      amountPaid: _paymentStatus == 'paid' ? t.finalTotal : 0,
      notes: _notesCtrl.text,
      termsAndConditions: _termsCtrl.text,
      templateId: _selectedTemplate,
      createdAt: DateTime.now(),
    );

    await _invoiceRepo.addInvoice(invoice);
    await _companyRepo.incrementInvoiceCounter();

    // Show interstitial after invoice creation
    AdMobService.showInterstitialAfterInvoiceCreation();

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => InvoicePreviewScreen(invoice: invoice),
        ),
      );
    }
  }

  void _previewInvoice() {
    // TODO: Show preview before saving
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Save invoice first to preview')));
  }
}

// ── Data class for line item entry ────────────────────────────────────
class _InvoiceItemEntry {
  String productName = '';
  String hsnSac = '';
  double quantity = 1;
  String unit = 'Nos';
  double price = 0;
  double discountPercent = 0;
  double gstRate = 18;
  bool isInclusive = false;
}

// ── Date Picker Widget ────────────────────────────────────────────────
class _DatePickerField extends StatelessWidget {
  final String label;
  final DateTime? selectedDate;
  final Function(DateTime) onDateSelected;
  final bool isOptional;

  const _DatePickerField({
    required this.label,
    required this.selectedDate,
    required this.onDateSelected,
    this.isOptional = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: selectedDate ?? DateTime.now(),
          firstDate: DateTime(2020),
          lastDate: DateTime(2030),
        );
        if (picked != null) onDateSelected(picked);
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          suffixIcon: const Icon(Icons.calendar_today, size: 18),
        ),
        child: Text(
          selectedDate != null
              ? DateFormat('dd/MM/yyyy').format(selectedDate!)
              : isOptional
                  ? 'Select date'
                  : 'Pick a date',
          style: TextStyle(
              color: selectedDate != null
                  ? Colors.black87
                  : Colors.grey),
        ),
      ),
    );
  }
}

// ── Customer Tile ─────────────────────────────────────────────────────
class _CustomerTile extends StatelessWidget {
  final CustomerModel customer;
  final VoidCallback onClear;
  final VoidCallback onTap;

  const _CustomerTile({
    required this.customer,
    required this.onClear,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.primaryBlue.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(customer.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 14)),
                Text('${customer.state} | ${customer.phone}',
                    style: const TextStyle(
                        fontSize: 12, color: AppTheme.textMedium)),
                if (customer.gstin.isNotEmpty)
                  Text('GSTIN: ${customer.gstin}',
                      style: const TextStyle(
                          fontSize: 11, color: AppTheme.textMedium)),
              ],
            ),
          ),
          IconButton(icon: const Icon(Icons.edit, size: 18), onPressed: onTap),
          IconButton(
              icon: const Icon(Icons.close, size: 18, color: Colors.red),
              onPressed: onClear),
        ],
      ),
    );
  }
}
