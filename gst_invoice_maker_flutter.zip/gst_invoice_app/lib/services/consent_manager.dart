import 'package:google_mobile_ads/google_mobile_ads.dart';

class ConsentManager {
  static bool _canRequestAds = false;

  static Future<void> initialize() async {
    final params = ConsentRequestParameters();

    await ConsentInformation.instance.requestConsentInfoUpdate(
      params,
      () async {
        // Show form if required
        if (await ConsentInformation.instance.isConsentFormAvailable()) {
          await _loadAndShowForm();
        } else {
          _canRequestAds = ConsentInformation.instance.canRequestAds();
        }
      },
      (error) {
        // On error, allow non-personalized ads
        _canRequestAds = true;
      },
    );
  }

  static Future<void> _loadAndShowForm() async {
    await ConsentForm.loadAndShowConsentFormIfRequired((error) {
      _canRequestAds = ConsentInformation.instance.canRequestAds();
    });
  }

  static Future<bool> canRequestAds() async {
    // If consent info not yet determined, default to allowing non-personalized
    _canRequestAds = ConsentInformation.instance.canRequestAds();
    return _canRequestAds;
  }

  /// Reset for testing
  static Future<void> resetForTesting() async {
    await ConsentInformation.instance.reset();
  }
}
